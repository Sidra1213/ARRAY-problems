import streamlit as st
from agent import route_request, profile_csv

st.set_page_config(page_title="StudyBuddy AI Agent", page_icon="📚", layout="centered")
st.title("📚 StudyBuddy AI Agent")
st.caption("A student-focused assistant with topic explanations, quizzes, study planning, and CSV checks.")

with st.sidebar:
    st.header("Study settings")
    minutes = st.slider("Study time (minutes)", min_value=10, max_value=120, value=30, step=5)
    st.markdown("---")
    st.subheader("Try these prompts")
    st.code("Explain linear regression")
    st.code("Quiz on train test split")
    st.code("Make a study plan for overfitting")
    st.markdown("---")
    st.caption("Demo version: responses use a small local knowledge base and routing rules. No API key is required.")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hey! I'm StudyBuddy. Ask me about an ML concept, request a quiz, or make a study plan."}
    ]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

prompt = st.chat_input("Ask an ML question or request a quiz...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    result = route_request(prompt, minutes)
    response = f"_{'Selected tool: ' + result['tool']}_\n\n{result['response']}"
    st.session_state.messages.append({"role": "assistant", "content": response})
    with st.chat_message("assistant"):
        st.markdown(response)

st.divider()
st.subheader("🧪 Dataset quick check")
st.write("Upload a CSV to inspect its shape, columns, missing values, duplicates, and numeric summary.")
uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
if uploaded_file is not None:
    st.markdown(profile_csv(uploaded_file))
