# StudyBuddy AI Agent

StudyBuddy is a small Python study agent for an introductory Machine Learning course.

## Features
- Routes student requests to different tools: concept explanation, quiz generation, and study planning.
- Recognizes selected introductory ML topics.
- Lets the user upload a CSV and inspect rows, columns, missing values, duplicates, and numeric summaries.
- Has a chat-style interface built with Streamlit.
- Does not need an API key or internet access after dependencies are installed.

## Important project scope
This is a **rule-based tool-routing agent prototype**, not a large language model. It uses a small local knowledge base and keyword-based routing. If the course rubric requires an LLM, LangChain, function calling, or an external API, those requirements must be added separately.

## Setup on Windows / VS Code

Open PowerShell in this folder and run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks activation, use the virtual environment's Python directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Start the app:

```powershell
python -m streamlit run app.py
```

The app opens in a browser, usually at `http://localhost:8501`.

## Tests

```powershell
python -m unittest -v
```

## Demo prompts
- `Explain linear regression`
- `Quiz on train test split`
- `Make a study plan for overfitting`
- Upload a CSV such as a salary prediction dataset.

## Agent workflow
1. Read the user's message.
2. Detect the likely topic.
3. Select a tool based on intent.
4. Run the selected tool.
5. Return the result to the user.

## Viva summary
"StudyBuddy is a student-support agent made with Python. Its router detects the user's intent and selects one of several tools. The explanation tool retrieves a short topic guide, the quiz tool creates MCQs from a local question bank, and the study-plan tool divides the user's available time into learning, practice, and review. A CSV checker uses Pandas to summarize uploaded data. Streamlit provides the user interface. The current version is rule-based, so it is transparent and does not require an API key."
