import unittest
from agent import route_request, find_topic, make_study_plan

class StudyBuddyTests(unittest.TestCase):
    def test_topic_detection(self):
        self.assertEqual(find_topic("Please explain linear regression"), "linear regression")
        self.assertEqual(find_topic("What is random_state?"), "train test split")

    def test_quiz_tool(self):
        result = route_request("Quiz me on linear regression")
        self.assertEqual(result["tool"], "quiz_tool")
        self.assertIn("Answer:", result["response"])

    def test_explain_tool(self):
        result = route_request("Explain overfitting")
        self.assertEqual(result["tool"], "explain_tool")
        self.assertIn("Overfitting", result["response"])

    def test_study_plan(self):
        result = make_study_plan("mae", 30)
        self.assertIn("30-minute study plan", result)

    def test_fallback(self):
        result = route_request("Hello")
        self.assertEqual(result["tool"], "help_tool")

if __name__ == "__main__":
    unittest.main()
