"""StudyBuddy AI Agent: simple tool-routing agent for student support."""
import random
import re
import pandas as pd

KNOWLEDGE = {
    "linear regression": {
        "definition": "Linear Regression predicts a numeric value by learning a relationship between input features and a target.",
        "example": "For example, it can estimate salary from years of experience.",
        "key_points": [
            "X contains the input feature(s), such as YearsExperience.",
            "y contains the target value, such as Salary.",
            "The model learns a best-fit line from training data.",
            "For new predictions, pass new X values to model.predict().",
        ],
    },
    "train test split": {
        "definition": "Train-test split divides data into two parts: training data to learn from and test data to evaluate on.",
        "example": "With test_size=0.2, about 80% is used for training and 20% for testing.",
        "key_points": [
            "X is the input feature data and y is the target.",
            "random_state=42 makes the split reproducible.",
            "The test set should be kept separate from model training.",
        ],
    },
    "overfitting": {
        "definition": "Overfitting happens when a model learns the training data too closely, including noise, and performs poorly on unseen data.",
        "example": "A model gets excellent training results but much worse test results.",
        "key_points": [
            "Compare training performance with test performance.",
            "Use simpler models, more data, or regularization when appropriate.",
            "Do not judge a model only by its training score.",
        ],
    },
    "mae": {
        "definition": "Mean Absolute Error (MAE) is the average absolute difference between actual and predicted values.",
        "example": "If MAE is 5, predictions are off by 5 target units on average.",
        "key_points": [
            "Lower MAE is generally better when comparing similar tasks.",
            "MAE is in the same units as the target.",
            "It does not show whether errors are positive or negative.",
        ],
    },
    "mse": {
        "definition": "Mean Squared Error (MSE) is the average of squared prediction errors.",
        "example": "Large errors are penalized more because errors are squared.",
        "key_points": [
            "Lower MSE is generally better for comparable models.",
            "MSE is expressed in squared target units.",
            "It is sensitive to large errors.",
        ],
    },
    "r2 score": {
        "definition": "R² score describes how well a regression model explains variation in the target compared with a simple baseline.",
        "example": "An R² near 1 often indicates a strong fit; it can be negative if the model performs worse than the baseline.",
        "key_points": [
            "It is not simply a percentage of predictions that are correct.",
            "Interpret it together with error metrics and the dataset.",
            "A high R² alone does not prove a model is suitable.",
        ],
    },
    "classification": {
        "definition": "Classification predicts a category or class, such as spam/not spam.",
        "example": "Predicting whether a flower belongs to a species is classification.",
        "key_points": [
            "The target is categorical.",
            "Common metrics include accuracy, precision, recall, and F1-score.",
            "Logistic Regression can be used for classification despite its name.",
        ],
    },
    "clustering": {
        "definition": "Clustering groups similar data points without using known target labels.",
        "example": "Grouping customers by similar purchasing patterns is clustering.",
        "key_points": [
            "It is an unsupervised learning task.",
            "K-Means is a common clustering algorithm.",
            "The number of clusters may need to be chosen.",
        ],
    },
}

QUIZZES = {
    "linear regression": [
        ("What kind of value does Linear Regression usually predict?", ["A numeric value", "Only categories", "A cluster label"], 0),
        ("In a salary prediction project, what is y?", ["Years of experience", "Salary target", "Row number"], 1),
        ("Which method makes predictions with a trained sklearn model?", ["model.predict()", "model.describe()", "model.drop()"], 0),
    ],
    "train test split": [
        ("Why do we keep a test set?", ["To train twice", "To evaluate on unseen data", "To delete missing values"], 1),
        ("What does random_state help with?", ["Reproducibility", "Increasing dataset size", "Changing target labels"], 0),
        ("If test_size=0.2, approximately what share is test data?", ["20%", "42%", "80%"], 0),
    ],
    "overfitting": [
        ("Which is a common sign of overfitting?", ["Poor training and test results", "Great training results but weak test results", "No training data"], 1),
        ("Overfitting means a model may learn:", ["Only the general pattern", "Noise in the training data too closely", "Nothing at all"], 1),
    ],
    "mae": [
        ("What does MAE stand for?", ["Mean Absolute Error", "Model Accuracy Estimate", "Maximum Average Error"], 0),
        ("MAE is usually better when it is:", ["Lower", "Higher", "Always exactly 100"], 0),
    ],
    "mse": [
        ("What happens to errors in MSE?", ["They are squared", "They are converted to labels", "They are ignored"], 0),
        ("MSE penalizes large errors:", ["More strongly", "Less strongly", "Not at all"], 0),
    ],
    "classification": [
        ("Classification predicts:", ["A numeric measurement only", "A category or class", "A row index"], 1),
        ("Which is a classification example?", ["Predicting house price", "Predicting spam or not spam", "Predicting tomorrow's temperature"], 1),
    ],
    "clustering": [
        ("Clustering is usually:", ["Supervised", "Unsupervised", "A file format"], 1),
        ("K-Means is commonly used for:", ["Clustering", "Text formatting", "Train-test splitting"], 0),
    ],
}

def find_topic(text):
    t = text.lower()
    aliases = {
        "linear regression": ["linear regression", "regression", "salary prediction"],
        "train test split": ["train test split", "train_test_split", "split data", "test_size", "random_state"],
        "overfitting": ["overfitting", "overfit"],
        "mae": ["mae", "mean absolute error"],
        "mse": ["mse", "mean squared error"],
        "r2 score": ["r2", "r²", "r2 score", "r squared"],
        "classification": ["classification", "classifier"],
        "clustering": ["clustering", "k-means", "kmeans"],
    }
    for topic, phrases in aliases.items():
        if any(p in t for p in phrases):
            return topic
    return None

def explain_topic(topic):
    item = KNOWLEDGE[topic]
    bullets = "\n".join(f"- {p}" for p in item["key_points"])
    return f"### {topic.title()}\n\n**Simple meaning:** {item['definition']}\n\n**Example:** {item['example']}\n\n**Remember:**\n{bullets}"

def make_quiz(topic, count=3):
    questions = QUIZZES.get(topic)
    if not questions:
        topic = "linear regression"
        questions = QUIZZES[topic]
    selected = questions[:min(count, len(questions))]
    lines = [f"### Quick quiz: {topic.title()}"]
    for i, (q, options, answer) in enumerate(selected, 1):
        lines.append(f"\n**{i}. {q}**")
        lines.extend(f"{chr(65+j)}. {option}" for j, option in enumerate(options))
        lines.append(f"**Answer:** {chr(65+answer)}. {options[answer]}")
    return "\n".join(lines)

def make_study_plan(topic, minutes=30):
    minutes = max(10, min(int(minutes), 180))
    explain = max(5, round(minutes * 0.4))
    practice = max(5, round(minutes * 0.4))
    review = max(2, minutes - explain - practice)
    return (
        f"### {minutes}-minute study plan: {topic.title()}\n\n"
        f"1. **{explain} min — Understand:** Read the explanation and write the definition in your own words.\n"
        f"2. **{practice} min — Practice:** Answer quiz questions and explain why each answer is correct.\n"
        f"3. **{review} min — Recall:** Close your notes and explain the topic aloud, then review mistakes."
    )

def profile_csv(file):
    """Return a compact, safe summary of an uploaded CSV."""
    try:
        df = pd.read_csv(file)
        if df.empty:
            return "The CSV is empty. Please upload a file containing rows and columns."
        lines = [
            "### Dataset quick check",
            f"- **Rows:** {df.shape[0]}",
            f"- **Columns:** {df.shape[1]}",
            f"- **Column names:** {', '.join(map(str, df.columns))}",
            f"- **Duplicate rows:** {int(df.duplicated().sum())}",
            f"- **Missing values by column:**",
        ]
        missing = df.isna().sum()
        lines.extend(f"  - {col}: {int(n)}" for col, n in missing.items())
        numeric = df.select_dtypes(include="number")
        if not numeric.empty:
            lines.append("\n**Numeric summary:**")
            lines.append(numeric.describe().round(2).to_markdown())
        lines.append("\n**Next step:** Decide which column is the target and which columns are input features before training a model.")
        return "\n".join(lines)
    except Exception as exc:
        return f"I couldn't read this CSV. Check that it is a valid comma-separated file. Details: {exc}"

def route_request(message, minutes=30):
    """Choose a tool based on the student's request."""
    text = message.strip()
    lower = text.lower()
    topic = find_topic(text)

    if any(word in lower for word in ["quiz", "test me", "mcq", "questions"]):
        topic = topic or "linear regression"
        return {"tool": "quiz_tool", "topic": topic, "response": make_quiz(topic)}
    if any(word in lower for word in ["study plan", "plan my", "schedule", "how should i study"]):
        topic = topic or "linear regression"
        return {"tool": "study_plan_tool", "topic": topic, "response": make_study_plan(topic, minutes)}
    if topic:
        return {"tool": "explain_tool", "topic": topic, "response": explain_topic(topic)}
    return {
        "tool": "help_tool",
        "topic": None,
        "response": (
            "I'm StudyBuddy, a small study agent. I can:\n\n"
            "- Explain Linear Regression, train-test split, overfitting, MAE, MSE, R², classification, or clustering.\n"
            "- Create a quiz: type **quiz on linear regression**.\n"
            "- Make a study plan: type **make a study plan for overfitting**.\n"
            "- Check a CSV dataset using the upload box.\n\n"
            "Try asking about one of these topics!"
        ),
    }
